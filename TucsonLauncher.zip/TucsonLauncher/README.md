# Launcher Tucson v2.1

Launcher Android para unidad de 1024x600 (Android 8.1, 1 GB RAM). Estilo azul, velocímetro,
clima, música, datos del vehículo por OBD2 (ELM327 Bluetooth) y dock de apps.

## Cómo obtener el APK (sin instalar nada)
1. Crea un repositorio nuevo en GitHub (por ejemplo `TucsonLauncher`).
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`).
3. Entra a la pestaña **Actions**: el flujo "Build APK" se ejecuta solo (5-8 min).
   Si no aparece, abre "Build APK" y pulsa **Run workflow**.
4. Cuando termine en verde, abre la ejecución y descarga **TucsonLauncher-apk** (abajo, en Artifacts).
5. Descomprime el ZIP descargado: dentro está `app-debug.apk`.

## Instalación en la unidad
1. Copia `app-debug.apk` a una memoria USB y conéctala a la unidad.
2. Ábrelo con el administrador de archivos y permite "orígenes desconocidos".
3. Pulsa el botón Home y elige **Launcher Tucson** como predeterminado ("Siempre").

## Primer uso
- Permiso de ubicación: acéptalo (velocidad por GPS y clima).
- Música: toca la tarjeta de música y activa "Acceso a notificaciones" para Launcher Tucson.
- OBD2: empareja el adaptador en Ajustes > Bluetooth (PIN 1234 o 0000), luego toca el
  botón "OBD2" de arriba y elígelo.
- Apps del dock: mantén pulsado un ícono para elegir otra app (útil para Radio y Mapas).
- Prueba sin auto: mantén pulsado el velocímetro para activar el modo demostración.

## Notas
- El consumo se calcula con el sensor MAF asumiendo motor a gasolina.
- El launcher solo LEE datos del vehículo; nunca escribe en la ECU.
- Si algo sale mal, instala otro launcher o desinstala este desde Ajustes > Aplicaciones.

## Novedades de la versión 2
- Botón **Aplicaciones** (cajón con todas las apps instaladas) y botón **Ajustes** en el dock.
- Se instala aparte de la versión 1 (identificador distinto): no hace falta desinstalar la anterior.
- Firma fija: las próximas versiones se instalarán encima de esta sin desinstalar.
- Arranque más ligero (servicios 3 s después) y **modo seguro** si se cierra 3 veces seguidas.
- Primera prueba recomendada: abrirlo como app normal desde el cajón del launcher de fábrica,
  y solo después dejarlo como predeterminado. Si la unidad falla al arrancar, el botón RST la recupera.

## Versión 2.1
- Clima: conserva el último dato cuando no hay internet y avisa el motivo
  ("Sin internet", "Sin ubicación"). Reintenta cada minuto si falla.

## Versión 2.2
- Tarjeta del clima rediseñada: ícono, temperatura, condición, ciudad y sensación térmica,
  máxima/mínima, humedad y viento.
- La ciudad se obtiene con OpenStreetMap (Nominatim) solo cuando cambias de zona; si falla, se omite.
