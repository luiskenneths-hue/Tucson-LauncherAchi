package com.tucson.launcher

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class MainActivity : Activity() {

    private data class DockApp(val key: String, val label: String, val packages: List<String>, val color: Int)
    private data class Launchable(val label: String, val pkg: String)

    private val h = Handler(Looper.getMainLooper())
    private var d = 1f
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var stage: FrameLayout

    private lateinit var gauge: GaugeView
    private lateinit var tvRpm: TextView
    private lateinit var barRpm: BarView
    private lateinit var tvWTemp: TextView
    private lateinit var tvWDesc: TextView
    private lateinit var tvWSub: TextView
    private lateinit var tvMax: TextView
    private lateinit var tvMin: TextView
    private lateinit var tvHum: TextView
    private lateinit var tvWind: TextView
    private lateinit var wIcon: WeatherIconView
    private lateinit var tvOut: TextView
    private lateinit var tvObd: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var cover: ImageView
    private lateinit var transport: TransportView
    private lateinit var tvCons: TextView
    private lateinit var tvDist: TextView
    private lateinit var tvEng: TextView
    private lateinit var tvVolt: TextView
    private lateinit var car: ImageView
    private val dockIcons = HashMap<String, ImageView>()

    private val dockApps = listOf(
        DockApp("maps", "Mapas", listOf("com.google.android.apps.maps"), Color.parseColor("#34A853")),
        DockApp("apps", "Aplicaciones", emptyList(), Color.parseColor("#2F8BFF")),
        DockApp("spotify", "Spotify", listOf("com.spotify.music"), Color.parseColor("#1DB954")),
        DockApp("youtube", "YouTube", listOf("com.google.android.youtube"), Color.parseColor("#E62117")),
        DockApp("phone", "Teléfono", emptyList(), Color.parseColor("#12A844")),
        DockApp("radio", "Radio", emptyList(), Color.parseColor("#6A4CFF")),
        DockApp("settings", "Ajustes", emptyList(), Color.parseColor("#64748B"))
    )

    private lateinit var drawer: FrameLayout
    private lateinit var grid: GridView
    private val iconCache = ConcurrentHashMap<String, Drawable>()
    private var safeMode = false

    // ---- estado ----
    private var demo = false
    private var demoT = 0.0
    private var lastTick = SystemClock.elapsedRealtime()
    private var gaugeShown = 0.0
    private var tripKm = 0.0
    private var tripL = 0.0

    @Volatile private var obdRpm: Int? = null
    @Volatile private var obdSpeed: Int? = null
    @Volatile private var obdCoolant: Int? = null
    @Volatile private var obdVolt: Double? = null
    @Volatile private var obdMaf: Double? = null
    @Volatile private var obdTime = 0L
    @Volatile private var obdStatus = ""
    private lateinit var obd: ObdManager

    @Volatile private var gpsSpeed = 0.0
    @Volatile private var gpsTime = 0L

    private var controller: MediaController? = null
    private var lastTrackKey = ""

    // ------------------------------------------------------------------------------------------
    // utilidades de UI
    // ------------------------------------------------------------------------------------------
    private fun dp(v: Int): Int = Math.round(v * d)
    private fun lp(x: Int, y: Int, w: Int, hh: Int): FrameLayout.LayoutParams =
        FrameLayout.LayoutParams(dp(w), dp(hh)).apply {
            gravity = Gravity.TOP or Gravity.START
            leftMargin = dp(x)
            topMargin = dp(y)
        }

    private fun tx(s: String, size: Int, color: Int = UI.TEXT, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_PX, size * d)
            setTextColor(color)
            typeface = if (bold) UI.FONT_B else UI.FONT
            includeFontPadding = false
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
        }

    private fun card(x: Int, y: Int, w: Int, hh: Int): FrameLayout {
        val f = FrameLayout(this)
        f.background = GradientDrawable().apply {
            setColor(UI.PANEL)
            setStroke(dp(1), UI.LINE)
            cornerRadius = 18f * d
        }
        stage.addView(f, lp(x, y, w, hh))
        return f
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------------------------------
    // ciclo de vida
    // ------------------------------------------------------------------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        obd = ObdManager(
            onData = { rpm, speed, coolant, volt, maf ->
                obdRpm = rpm; obdSpeed = speed; obdCoolant = coolant; obdVolt = volt; obdMaf = maf
                obdTime = SystemClock.elapsedRealtime()
            },
            onStatus = { s -> obdStatus = s }
        )

        buildUi()
        setContentView(root)

        // Modo seguro: si la app se cierra 3 veces seguidas en los primeros 15 s,
        // el siguiente arranque no inicia servicios (OBD, GPS, clima, musica).
        val starts = prefs.getInt("starts", 0)
        safeMode = starts >= 3
        prefs.edit().putInt("starts", starts + 1).apply()
        h.postDelayed({ prefs.edit().putInt("starts", 0).apply() }, 15000L)
        if (safeMode) toast("Modo seguro: servicios desactivados en este arranque")

        h.post(object : Runnable {
            override fun run() {
                tick()
                h.postDelayed(this, 200)
            }
        })

        showCachedWeather("Buscando clima…")

        // Los servicios arrancan 3 s despues para no cargar el inicio del sistema.
        if (!safeMode) {
            h.postDelayed({
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
                } else {
                    startLocation()
                }
                val saved = prefs.getString("obd_addr", null)
                if (saved != null) obd.start(saved)
                refreshWeather()
                h.post(object : Runnable {
                    override fun run() {
                        pollMedia()
                        h.postDelayed(this, 1000)
                    }
                })
            }, 3000L)
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        obd.stop()
        try {
            (getSystemService(Context.LOCATION_SERVICE) as LocationManager).removeUpdates(locListener)
        } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onBackPressed() {
        // Es el launcher: no se cierra con Atras, pero si cierra el cajon de apps.
        if (drawer.visibility == View.VISIBLE) hideDrawer()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (::drawer.isInitialized) hideDrawer()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startLocation()
            refreshWeather()
        }
    }

    // ------------------------------------------------------------------------------------------
    // construccion de la interfaz (lienzo de 1024x600 escalado a la pantalla real)
    // ------------------------------------------------------------------------------------------
    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(UI.BG)
        stage = FrameLayout(this)
        stage.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = 520f * d
            setGradientCenter(0.5f, 0.55f)
            colors = intArrayOf(Color.parseColor("#0E2550"), UI.BG)
        }
        root.addView(stage, FrameLayout.LayoutParams(dp(1024), dp(600), Gravity.CENTER))
        stage.pivotX = dp(1024) / 2f
        stage.pivotY = dp(600) / 2f
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val rw = r - l
            val rh = b - t
            if (rw > 0 && rh > 0) {
                val s = min(rw / dp(1024).toFloat(), rh / dp(600).toFloat())
                stage.scaleX = s
                stage.scaleY = s
            }
        }

        buildTopBar()
        buildSpeed()
        buildCenter()
        buildRight()
        buildDock()
        buildDrawer()
    }

    private fun buildTopBar() {
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 26 * d)
            setTextColor(UI.TEXT)
            typeface = UI.FONT_B
            includeFontPadding = false
        }
        stage.addView(clock, lp(24, 14, 140, 36))

        tvObd = tx("OBD2: toca para elegir", 14, UI.MUTED).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1A2F8BFF"))
                setStroke(dp(1), UI.LINE)
                cornerRadius = 20f * d
            }
            setOnClickListener { pickObd() }
        }
        stage.addView(tvObd, lp(690, 14, 220, 32))

        tvOut = tx("--°C", 24, UI.TEXT, true).apply { gravity = Gravity.END }
        stage.addView(tvOut, lp(900, 14, 100, 34))
    }

    private fun buildSpeed() {
        gauge = GaugeView(this)
        gauge.setOnLongClickListener {
            demo = !demo
            tripKm = 0.0
            tripL = 0.0
            toast(if (demo) "Modo demostración activado" else "Modo demostración desactivado")
            true
        }
        stage.addView(gauge, lp(16, 52, 240, 240))

        val rpm = card(16, 300, 240, 60)
        rpm.addView(tx("Revoluciones", 15, UI.MUTED), lp(16, 10, 110, 20))
        tvRpm = tx("-- rpm", 22, UI.TEXT, true).apply { gravity = Gravity.END }
        rpm.addView(tvRpm, lp(120, 6, 104, 28))
        barRpm = BarView(this)
        rpm.addView(barRpm, lp(16, 44, 208, 8))

        val w = card(16, 368, 240, 112)
        wIcon = WeatherIconView(this)
        w.addView(wIcon, lp(10, 10, 46, 46))
        tvWTemp = tx("--°", 38, UI.TEXT, true)
        w.addView(tvWTemp, lp(58, 8, 66, 46))
        tvWDesc = tx("Buscando clima…", 15, UI.TEXT, true)
        w.addView(tvWDesc, lp(124, 12, 110, 20))
        tvWSub = tx("", 12, UI.MUTED)
        w.addView(tvWSub, lp(124, 34, 110, 18))

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#4D5C7FB0"))
                cornerRadius = 16f * d
            }
        }
        fun pillText(t: String): TextView = tx(t, 14, UI.TEXT).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(7) }
        }
        tvMax = pillText("↑--°")
        tvMin = pillText("↓--°")
        val drop = DropView(this)
        tvHum = pillText("--%")
        tvWind = pillText("-- km/h")
        pill.addView(tvMax)
        pill.addView(tvMin)
        pill.addView(drop, LinearLayout.LayoutParams(dp(11), dp(15)).apply { rightMargin = dp(3) })
        pill.addView(tvHum)
        pill.addView(tvWind)
        w.addView(pill, lp(10, 70, 220, 32))
    }

    private fun buildCenter() {
        val brand = tx("HYUNDAI", 26, UI.TEXT, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.35f
        }
        stage.addView(brand, lp(282, 58, 460, 34))
        val u = View(this).apply {
            background = GradientDrawable().apply { setColor(UI.ACCENT); cornerRadius = 2f * d }
        }
        stage.addView(u, lp(490, 98, 44, 3))

        stage.addView(PlatformView(this), lp(252, 330, 520, 110))

        car = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageResource(R.drawable.car_line)
        }
        stage.addView(car, lp(292, 126, 440, 245))
        car.post {
            val w = car.width
            val hh = car.height
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1600
                interpolator = DecelerateInterpolator()
                addUpdateListener { car.clipBounds = Rect(0, 0, (w * (it.animatedValue as Float)).toInt(), hh) }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        car.clipBounds = null
                    }
                })
                start()
            }
        }
    }

    private fun buildRight() {
        val m = card(758, 52, 250, 132)
        m.setOnClickListener {
            if (!hasListenerAccess()) {
                try {
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                } catch (e: Exception) {
                    toast("Activa el acceso a notificaciones para Launcher Tucson en Ajustes")
                }
            }
        }
        cover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { setColor(Color.parseColor("#12306A")); cornerRadius = 12f * d }
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 12f * d)
                }
            }
            clipToOutline = true
        }
        m.addView(cover, lp(14, 14, 74, 74))
        tvTitle = tx("Sin reproducción", 20, UI.TEXT, true)
        m.addView(tvTitle, lp(100, 18, 138, 26))
        tvArtist = tx("", 15, UI.MUTED)
        m.addView(tvArtist, lp(100, 48, 138, 22))
        transport = TransportView(this,
            onPrev = { controller?.transportControls?.skipToPrevious() },
            onPlay = {
                val c = controller
                if (c != null) {
                    if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                    else c.transportControls.play()
                }
            },
            onNext = { controller?.transportControls?.skipToNext() })
        m.addView(transport, lp(10, 92, 230, 34))

        val data = card(758, 194, 250, 278)
        val rows = listOf("Consumo promedio", "Distancia recorrida", "Temp. motor", "Voltaje batería")
        val vals = ArrayList<TextView>()
        for ((i, label) in rows.withIndex()) {
            val y = 8 + i * 68
            data.addView(tx(label, 15, UI.MUTED), lp(18, y + 6, 214, 20))
            val v = tx("--", 26, UI.TEXT, true)
            data.addView(v, lp(18, y + 28, 214, 32))
            vals.add(v)
            if (i < rows.size - 1) {
                val line = View(this).apply { setBackgroundColor(Color.parseColor("#14FFFFFF")) }
                data.addView(line, lp(18, y + 66, 214, 1))
            }
        }
        tvCons = vals[0]; tvDist = vals[1]; tvEng = vals[2]; tvVolt = vals[3]
    }

    private fun buildDock() {
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        stage.addView(dock, lp(40, 488, 944, 104))
        for (app in dockApps) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                isFocusable = true
            }
            val icon = ImageView(this)
            val label = tx(app.label, 15, UI.MUTED).apply { gravity = Gravity.CENTER }
            item.addView(icon, LinearLayout.LayoutParams(dp(66), dp(66)))
            item.addView(label, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
            dock.addView(item, LinearLayout.LayoutParams(dp(134), ViewGroup.LayoutParams.WRAP_CONTENT))
            dockIcons[app.key] = icon
            refreshIcon(app)
            item.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.alpha = 0.6f
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
                }
                false
            }
            item.setOnClickListener { launch(app) }
            item.setOnLongClickListener { if (app.key != "apps") pickApp(app); true }
        }
    }

    // ------------------------------------------------------------------------------------------
    // dock: apps
    // ------------------------------------------------------------------------------------------
    private fun launchables(): List<Launchable> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { Launchable(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        packageManager.getLaunchIntentForPackage(pkg) != null
    } catch (e: Exception) {
        false
    }

    private fun resolvePkg(app: DockApp): String? {
        val saved = prefs.getString("pkg_" + app.key, null)
        if (saved != null && isInstalled(saved)) return saved
        for (p in app.packages) if (isInstalled(p)) return p
        if (app.key == "radio") {
            return launchables().firstOrNull {
                val l = it.label.lowercase()
                l.contains("radio") || l == "fm"
            }?.pkg
        }
        return null
    }

    private fun refreshIcon(app: DockApp) {
        val icon = dockIcons[app.key] ?: return
        val pkg = resolvePkg(app)
        var dr: Drawable? = null
        try {
            if (pkg != null) {
                dr = packageManager.getApplicationIcon(pkg)
            } else if (app.key == "phone") {
                dr = packageManager.resolveActivity(Intent(Intent.ACTION_DIAL), 0)?.loadIcon(packageManager)
            } else if (app.key == "settings") {
                dr = packageManager.resolveActivity(Intent(Settings.ACTION_SETTINGS), 0)?.loadIcon(packageManager)
            }
        } catch (e: Exception) { }
        if (app.key == "apps") dr = AppsIconDrawable()
        icon.setImageDrawable(dr ?: LetterDrawable(app.label.take(1), app.color))
    }

    private fun launch(app: DockApp) {
        if (app.key == "apps") {
            showDrawer()
            return
        }
        try {
            val pkg = resolvePkg(app)
            if (pkg != null) {
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) {
                    startActivity(i)
                    return
                }
            }
            if (app.key == "phone") {
                startActivity(Intent(Intent.ACTION_DIAL))
                return
            }
            if (app.key == "settings") {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                return
            }
        } catch (e: Exception) { }
        toast("Mantén pulsado el ícono para elegir la app de ${app.label}")
    }

    private fun pickApp(app: DockApp) {
        val list = launchables()
        val labels = list.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("App para ${app.label}")
            .setItems(labels) { _, i ->
                prefs.edit().putString("pkg_" + app.key, list[i].pkg).apply()
                refreshIcon(app)
            }
            .setNeutralButton("Restablecer") { _, _ ->
                prefs.edit().remove("pkg_" + app.key).apply()
                refreshIcon(app)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------------------------------
    // cajon de aplicaciones
    // ------------------------------------------------------------------------------------------
    private fun buildDrawer() {
        drawer = FrameLayout(this)
        drawer.setBackgroundColor(Color.parseColor("#F2040811"))
        drawer.visibility = View.GONE
        drawer.isClickable = true
        drawer.addView(tx("Aplicaciones", 30, UI.TEXT, true), lp(48, 22, 500, 40))

        val close = tx("×", 34, UI.TEXT, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(UI.PANEL)
                setStroke(dp(1), UI.LINE)
                shape = GradientDrawable.OVAL
            }
            setOnClickListener { hideDrawer() }
        }
        drawer.addView(close, lp(924, 16, 52, 52))

        grid = GridView(this).apply {
            numColumns = 7
            verticalSpacing = dp(14)
            selector = Color.TRANSPARENT.let { android.graphics.drawable.ColorDrawable(it) }
            isVerticalScrollBarEnabled = false
        }
        drawer.addView(grid, lp(32, 84, 960, 504))
        stage.addView(drawer, FrameLayout.LayoutParams(dp(1024), dp(600)))
    }

    private fun showDrawer() {
        drawer.visibility = View.VISIBLE
        Thread {
            val list = launchables()
            for (a in list) {
                if (!iconCache.containsKey(a.pkg)) {
                    try {
                        iconCache[a.pkg] = packageManager.getApplicationIcon(a.pkg)
                    } catch (e: Exception) { }
                }
            }
            runOnUiThread {
                grid.adapter = AppAdapter(list)
                grid.setOnItemClickListener { _, _, pos, _ ->
                    try {
                        packageManager.getLaunchIntentForPackage(list[pos].pkg)?.let { startActivity(it) }
                    } catch (e: Exception) { }
                    hideDrawer()
                }
            }
        }.start()
    }

    private fun hideDrawer() {
        drawer.visibility = View.GONE
    }

    private inner class AppAdapter(val items: List<Launchable>) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                addView(ImageView(this@MainActivity), LinearLayout.LayoutParams(dp(60), dp(60)))
                addView(
                    tx("", 14, UI.MUTED).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        .apply { topMargin = dp(4) }
                )
            }
            val a = items[position]
            (v.getChildAt(0) as ImageView).setImageDrawable(iconCache[a.pkg] ?: LetterDrawable(a.label.take(1), UI.ACCENT))
            (v.getChildAt(1) as TextView).text = a.label
            return v
        }
    }

    // ------------------------------------------------------------------------------------------
    // OBD2
    // ------------------------------------------------------------------------------------------
    private fun pickObd() {
        val ad = BluetoothAdapter.getDefaultAdapter()
        if (ad == null || !ad.isEnabled) {
            toast("Activa el Bluetooth de la unidad")
            return
        }
        val devs = ad.bondedDevices.toList()
        if (devs.isEmpty()) {
            toast("Primero empareja el adaptador OBD2 (PIN 1234 o 0000) en Ajustes > Bluetooth")
            return
        }
        val names = devs.map { "${it.name} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Adaptador OBD2")
            .setItems(names) { _, i ->
                prefs.edit().putString("obd_addr", devs[i].address).apply()
                tripKm = 0.0
                tripL = 0.0
                obd.start(devs[i].address)
            }
            .setNeutralButton("Desconectar") { _, _ ->
                prefs.edit().remove("obd_addr").apply()
                obd.stop()
                obdStatus = ""
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ------------------------------------------------------------------------------------------
    // GPS y clima
    // ------------------------------------------------------------------------------------------
    private val locListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            if (location.hasSpeed()) {
                gpsSpeed = location.speed * 3.6
                gpsTime = SystemClock.elapsedRealtime()
            }
        }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
        } catch (e: Exception) { }
    }

    private val weatherTask = Runnable { refreshWeather() }

    private fun refreshWeather() {
        Thread {
            var ok = false
            var msg: String? = null
            try {
                var lat: Double? = null
                var lon: Double? = null
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    for (p in lm.getProviders(true)) {
                        val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                        if (l != null) {
                            lat = l.latitude
                            lon = l.longitude
                            break
                        }
                    }
                }
                if (lat == null || lon == null) {
                    lat = prefs.getString("lat", null)?.toDoubleOrNull()
                    lon = prefs.getString("lon", null)?.toDoubleOrNull()
                }
                if (lat == null || lon == null) {
                    val ip = Weather.ipLocation()
                    if (ip != null) {
                        lat = ip.first
                        lon = ip.second
                    }
                }
                val la = lat
                val lo = lon
                if (la != null && lo != null) {
                    prefs.edit().putString("lat", la.toString()).putString("lon", lo.toString()).apply()
                    val w = Weather.fetch(la, lo)
                    if (w != null) {
                        ok = true
                        prefs.edit().putString("w_json", w.toJson()).apply()
                        val city = cityFor(la, lo)
                        runOnUiThread { showWeather(w, city, null) }
                    } else {
                        msg = "Clima no disponible"
                    }
                } else {
                    msg = "Sin ubicación"
                }
            } catch (e: java.io.IOException) {
                msg = "Sin internet"
            } catch (e: Exception) {
                msg = "Clima no disponible"
            }
            val reason = msg
            val success = ok
            runOnUiThread {
                if (!success) showCachedWeather(reason ?: "Clima no disponible")
                h.removeCallbacks(weatherTask)
                // Si falla, reintenta en 1 minuto; si sale bien, cada 15 minutos.
                h.postDelayed(weatherTask, if (success) 15 * 60 * 1000L else 60 * 1000L)
            }
        }.start()
    }

    /** Ciudad: se consulta solo si cambiaste de zona (mas de ~0.15 grados) o aun no se tiene. */
    private fun cityFor(lat: Double, lon: Double): String? {
        val saved = prefs.getString("city", null)
        val sl = prefs.getString("city_lat", null)?.toDoubleOrNull()
        val so = prefs.getString("city_lon", null)?.toDoubleOrNull()
        val near = sl != null && so != null && Math.abs(sl - lat) < 0.15 && Math.abs(so - lon) < 0.15
        if (saved != null && near) return saved
        val c = Weather.city(lat, lon) ?: return saved
        prefs.edit().putString("city", c).putString("city_lat", lat.toString()).putString("city_lon", lon.toString()).apply()
        return c
    }

    private fun showWeather(w: Weather.Current, city: String?, label: String?) {
        val t = Math.round(w.temp).toInt()
        tvWTemp.text = "$t°"
        tvOut.text = "$t°C"
        tvWDesc.text = label ?: Weather.describe(w.code)
        val feels = Math.round(w.feels).toInt()
        tvWSub.text = if (city != null) "$city · Sens. $feels°" else "Sensación $feels°"
        tvMax.text = "↑" + Math.round(w.tMax).toInt() + "°"
        tvMin.text = "↓" + Math.round(w.tMin).toInt() + "°"
        tvHum.text = w.humidity.toString() + "%"
        tvWind.text = Math.round(w.wind).toInt().toString() + " km/h"
        wIcon.set(w.code, w.isDay)
    }

    /** Muestra el ultimo dato guardado (si existe) junto con el motivo por el que no se actualizo. */
    private fun showCachedWeather(reason: String) {
        val w = Weather.fromJson(prefs.getString("w_json", null))
        if (w != null) showWeather(w, prefs.getString("city", null), reason) else tvWDesc.text = reason
    }

    // ------------------------------------------------------------------------------------------
    // musica
    // ------------------------------------------------------------------------------------------
    private fun hasListenerAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun pollMedia() {
        var list: List<MediaController>? = null
        try {
            val mgr = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            list = mgr.getActiveSessions(ComponentName(this, MediaService::class.java))
        } catch (e: Exception) { }
        val c = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        controller = c
        if (c == null) {
            tvTitle.text = "Sin reproducción"
            tvArtist.text = if (hasListenerAccess()) "Abre Spotify u otra app" else "Toca aquí para activar"
            transport.playing = false
            if (lastTrackKey != "") {
                cover.setImageDrawable(null)
                lastTrackKey = ""
            }
            return
        }
        transport.playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Reproduciendo"
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        tvTitle.text = title
        tvArtist.text = artist
        val key = title + "|" + artist
        if (key != lastTrackKey) {
            lastTrackKey = key
            val art: Bitmap? = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            if (art != null) cover.setImageBitmap(art) else cover.setImageDrawable(null)
        }
    }

    // ------------------------------------------------------------------------------------------
    // ciclo de datos (cada 200 ms)
    // ------------------------------------------------------------------------------------------
    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val dt = min(now - lastTick, 1000L)
        lastTick = now

        val speed: Double
        val rpm: Int?
        val eng: Int?
        val volt: Double?
        val maf: Double?
        if (demo) {
            demoT += dt / 1000.0
            speed = max(0.0, 62 + 48 * sin(demoT / 7) + 8 * sin(demoT / 1.7))
            rpm = (780 + speed * 24 + 90 * sin(demoT * 3)).toInt()
            eng = (88 + 3 * sin(demoT / 20)).toInt()
            volt = 14.1 + 0.15 * sin(demoT / 5)
            maf = 4.0 + speed * 0.12
        } else {
            val fresh = now - obdTime < 3000
            val os = obdSpeed
            rpm = if (fresh) obdRpm else null
            eng = if (fresh) obdCoolant else null
            volt = if (fresh) obdVolt else null
            maf = if (fresh) obdMaf else null
            speed = if (fresh && os != null) os.toDouble() else if (now - gpsTime < 3000) gpsSpeed else 0.0
        }

        if (speed > 0.5) tripKm += speed * dt / 3_600_000.0
        if (maf != null && (rpm ?: 0) > 0) tripL += maf * FUEL_LPH_PER_GS * dt / 3_600_000.0

        gaugeShown += (speed - gaugeShown) * 0.45
        gauge.value = gaugeShown.toFloat()
        tvRpm.text = if (rpm != null) "$rpm rpm" else "-- rpm"
        barRpm.set((rpm ?: 0) / 6500f, (rpm ?: 0) > 5000)
        tvEng.text = if (eng != null) "$eng °C" else "-- °C"
        tvEng.setTextColor(if ((eng ?: 0) > 105) UI.WARN else UI.TEXT)
        tvVolt.text = if (volt != null) String.format("%.1f V", volt) else "-- V"
        tvDist.text = String.format("%.1f km", tripKm)
        tvCons.text = if (tripKm > 0.3 && tripL > 0) String.format("%.1f L/100 km", tripL / tripKm * 100) else "-- L/100 km"

        val addr = prefs.getString("obd_addr", null)
        tvObd.text = when {
            demo -> "Modo demostración"
            addr == null -> "OBD2: toca para elegir"
            else -> "OBD2: " + (if (obdStatus.isEmpty()) "…" else obdStatus)
        }
        tvObd.setTextColor(if (demo || obdStatus == "Conectado") UI.GLOW else UI.MUTED)
    }

    companion object {
        /** Gasolina: litros/hora por cada g/s de aire (relacion 14.7:1, densidad 745 g/L). */
        private const val FUEL_LPH_PER_GS = 0.3287
    }
}
