package com.tucson.launcher

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Lector OBD2 por Bluetooth (ELM327). SOLO LECTURA: unicamente envia comandos de
 * configuracion del adaptador (AT...) y consultas de modo 01 (datos en vivo).
 */
class ObdManager(
    private val onData: (rpm: Int?, speed: Int?, coolant: Int?, volt: Double?, maf: Double?) -> Unit,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var gen = 0
    @Volatile private var running = false
    private var thread: Thread? = null
    private var lastStatus = ""

    fun start(address: String) {
        stop()
        running = true
        val g = ++gen
        thread = Thread { loop(address, g) }.apply { isDaemon = true; start() }
    }

    fun stop() {
        running = false
        gen++
        thread?.interrupt()
        thread = null
    }

    private fun alive(g: Int) = running && g == gen

    private fun status(s: String) {
        if (s != lastStatus) {
            lastStatus = s
            onStatus(s)
        }
    }

    private fun loop(address: String, g: Int) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            status("Sin Bluetooth")
            return
        }
        while (alive(g)) {
            var socket: BluetoothSocket? = null
            try {
                status("Conectando…")
                adapter.cancelDiscovery()
                socket = adapter.getRemoteDevice(address).createRfcommSocketToServiceRecord(SPP)
                socket.connect()
                val inp = socket.inputStream
                val out = socket.outputStream
                query(out, inp, "ATZ", 4000)
                for (c in arrayOf("ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) query(out, inp, c, 2000)

                var rpm: Int? = null
                var speed: Int? = null
                var coolant: Int? = null
                var volt: Double? = null
                var maf: Double? = null
                var n = 0
                while (alive(g)) {
                    var got = false
                    data(query(out, inp, "010C"), "410C")?.let {
                        if (it.size >= 2) { rpm = (it[0] * 256 + it[1]) / 4; got = true }
                    }
                    data(query(out, inp, "010D"), "410D")?.let {
                        if (it.isNotEmpty()) { speed = it[0]; got = true }
                    }
                    data(query(out, inp, "0105"), "4105")?.let {
                        if (it.isNotEmpty()) { coolant = it[0] - 40; got = true }
                    }
                    data(query(out, inp, "0110"), "4110")?.let {
                        if (it.size >= 2) { maf = (it[0] * 256 + it[1]) / 100.0; got = true }
                    }
                    if (n % 5 == 0) {
                        val v = data(query(out, inp, "0142"), "4142")
                        if (v != null && v.size >= 2) {
                            volt = (v[0] * 256 + v[1]) / 1000.0
                        } else {
                            val r = query(out, inp, "ATRV")
                            Regex("([0-9]+\\.?[0-9]*)\\s*V").find(r)?.let { volt = it.groupValues[1].toDoubleOrNull() }
                        }
                    }
                    n++
                    if (got) {
                        status("Conectado")
                        onData(rpm, speed, coolant, volt, maf)
                    } else {
                        status("Conectado, sin datos del motor")
                        onData(null, null, null, volt, null)
                        Thread.sleep(800)
                    }
                }
            } catch (e: InterruptedException) {
                // detenido
            } catch (e: Exception) {
                status("Sin conexión")
            } finally {
                try { socket?.close() } catch (e: Exception) { }
            }
            if (alive(g)) {
                try { Thread.sleep(4000) } catch (e: InterruptedException) { }
            }
        }
    }

    private fun query(out: OutputStream, inp: InputStream, cmd: String, timeoutMs: Long = 2500): String {
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val sb = StringBuilder()
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (inp.available() > 0) {
                val c = inp.read()
                if (c < 0) throw IOException("cerrado")
                if (c.toChar() == '>') break
                sb.append(c.toChar())
            } else {
                Thread.sleep(10)
            }
        }
        return sb.toString()
    }

    private fun data(resp: String, prefix: String): IntArray? {
        for (line in resp.split('\r', '\n')) {
            val l = line.replace(" ", "").uppercase()
            if (l.startsWith(prefix)) {
                val hex = l.substring(prefix.length)
                val vals = ArrayList<Int>()
                var i = 0
                while (i + 1 < hex.length) {
                    val v = hex.substring(i, i + 2).toIntOrNull(16) ?: return null
                    vals.add(v)
                    i += 2
                }
                return vals.toIntArray()
            }
        }
        return null
    }

    companion object {
        private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}
