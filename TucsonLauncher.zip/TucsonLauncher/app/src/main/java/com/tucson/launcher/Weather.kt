package com.tucson.launcher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Weather {
    data class Current(
        val temp: Double,
        val feels: Double,
        val humidity: Int,
        val wind: Double,
        val code: Int,
        val isDay: Boolean,
        val tMax: Double,
        val tMin: Double
    ) {
        fun toJson(): String = JSONObject()
            .put("temp", temp).put("feels", feels).put("hum", humidity).put("wind", wind)
            .put("code", code).put("day", isDay).put("max", tMax).put("min", tMin)
            .toString()
    }

    fun fromJson(s: String?): Current? {
        if (s == null) return null
        return try {
            val o = JSONObject(s)
            Current(
                o.getDouble("temp"), o.getDouble("feels"), o.getInt("hum"), o.getDouble("wind"),
                o.getInt("code"), o.getBoolean("day"), o.getDouble("max"), o.getDouble("min")
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "TucsonLauncher/2.2 (uso personal)")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun fetch(lat: Double, lon: Double): Current? {
        val txt = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code,is_day" +
                "&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto"
        )
        val o = JSONObject(txt)
        val cur = o.getJSONObject("current")
        val daily = o.getJSONObject("daily")
        return Current(
            temp = cur.getDouble("temperature_2m"),
            feels = cur.getDouble("apparent_temperature"),
            humidity = cur.getDouble("relative_humidity_2m").toInt(),
            wind = cur.getDouble("wind_speed_10m"),
            code = cur.getInt("weather_code"),
            isDay = cur.getInt("is_day") == 1,
            tMax = daily.getJSONArray("temperature_2m_max").getDouble(0),
            tMin = daily.getJSONArray("temperature_2m_min").getDouble(0)
        )
    }

    /** Nombre de la ciudad a partir de coordenadas. Si falla, devuelve null y se omite. */
    fun city(lat: Double, lon: Double): String? = try {
        val o = JSONObject(
            get("https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lon&zoom=10&accept-language=es")
        )
        val a = o.optJSONObject("address")
        var r: String? = null
        if (a != null) {
            for (k in arrayOf("city", "town", "village", "municipality", "suburb", "county", "state")) {
                val v = a.optString(k, "")
                if (v.isNotEmpty()) {
                    r = v
                    break
                }
            }
        }
        r
    } catch (e: Exception) {
        null
    }

    /** Ubicacion aproximada por IP, solo si el equipo no tiene GPS ni ubicacion guardada. */
    fun ipLocation(): Pair<Double, Double>? {
        val o = JSONObject(get("https://ipwho.is/"))
        if (!o.optBoolean("success", false)) return null
        return Pair(o.getDouble("latitude"), o.getDouble("longitude"))
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Despejado"
        1 -> "Mayormente despejado"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        51, 53, 55 -> "Llovizna"
        56, 57 -> "Llovizna helada"
        61, 63, 65 -> "Lluvia"
        66, 67 -> "Lluvia helada"
        71, 73, 75, 77 -> "Nieve"
        80, 81, 82 -> "Chubascos"
        85, 86 -> "Chubascos de nieve"
        95 -> "Tormenta"
        96, 99 -> "Tormenta con granizo"
        else -> "--"
    }
}
