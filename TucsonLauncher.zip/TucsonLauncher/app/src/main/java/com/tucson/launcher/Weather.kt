package com.tucson.launcher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Weather {
    data class Current(val temp: Double, val code: Int)

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun fetch(lat: Double, lon: Double): Current? {
        val txt = get(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code&timezone=auto"
        )
        val cur = JSONObject(txt).getJSONObject("current")
        return Current(cur.getDouble("temperature_2m"), cur.getInt("weather_code"))
    }

    /** Ubicacion aproximada por IP, solo si el equipo no tiene GPS ni ubicacion guardada. */
    fun ipLocation(): Pair<Double, Double>? {
        val o = JSONObject(get("https://ipwho.is/"))
        if (!o.optBoolean("success", false)) return null
        return Pair(o.getDouble("latitude"), o.getDouble("longitude"))
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Despejado"
        1 -> "Mayormente despejado"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        51, 53, 55 -> "Llovizna"
        56, 57 -> "Llovizna helada"
        61, 63, 65 -> "Lluvia"
        66, 67 -> "Lluvia helada"
        71, 73, 75, 77 -> "Nieve"
        80, 81, 82 -> "Chubascos"
        85, 86 -> "Chubascos de nieve"
        95 -> "Tormenta"
        96, 99 -> "Tormenta con granizo"
        else -> "--"
    }
}
