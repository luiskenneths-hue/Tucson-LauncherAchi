package com.tucson.launcher

import android.service.notification.NotificationListenerService

/**
 * Servicio vacio: su unica funcion es que el usuario pueda darle "acceso a notificaciones",
 * lo cual permite al launcher leer que cancion suena y controlar la reproduccion.
 */
class MediaService : NotificationListenerService()
