package com.tucson.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View

object UI {
    val BG: Int = Color.parseColor("#040811")
    val PANEL: Int = Color.parseColor("#6B102246")
    val LINE: Int = Color.parseColor("#1C3A6E")
    val ACCENT: Int = Color.parseColor("#2F8BFF")
    val GLOW: Int = Color.parseColor("#5CC8FF")
    val TEXT: Int = Color.parseColor("#E8F1FF")
    val MUTED: Int = Color.parseColor("#7F93B5")
    val WARN: Int = Color.parseColor("#FFB347")
    val FONT: Typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
    val FONT_B: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val FONT_BI: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
}

/** Velocimetro: arco de 270 grados con numero grande al centro. */
class GaugeView(ctx: Context) : View(ctx) {
    var value = 0f
        set(v) {
            field = v
            invalidate()
        }
    var maxValue = 200f

    private val d = ctx.resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#12284F")
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.parseColor("#552F8BFF")
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = UI.TEXT; textAlign = Paint.Align.CENTER; typeface = UI.FONT_BI
    }
    private val unit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = UI.MUTED; textAlign = Paint.Align.CENTER; typeface = UI.FONT
    }
    private val rect = RectF()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val sw = w * 0.045f
        track.strokeWidth = sw
        arc.strokeWidth = sw
        glow.strokeWidth = sw * 2.2f
        val pad = sw * 1.6f
        rect.set(pad, pad, w - pad, h - pad)
        arc.shader = LinearGradient(0f, h.toFloat(), w.toFloat(), 0f, UI.ACCENT, UI.GLOW, Shader.TileMode.CLAMP)
        num.textSize = w * 0.36f
        unit.textSize = w * 0.075f
    }

    override fun onDraw(c: Canvas) {
        c.drawArc(rect, 135f, 270f, false, track)
        val sweep = 270f * (value / maxValue).coerceIn(0f, 1f)
        if (sweep > 0.5f) {
            c.drawArc(rect, 135f, sweep, false, glow)
            c.drawArc(rect, 135f, sweep, false, arc)
        }
        val cx = width / 2f
        val base = height / 2f + num.textSize * 0.28f
        c.drawText(value.toInt().toString(), cx, base, num)
        c.drawText("km/h", cx, base + unit.textSize * 1.5f, unit)
        unit.textSize = width * 0.06f
        c.drawText("0", width * 0.22f, height * 0.93f, unit)
        c.drawText(maxValue.toInt().toString(), width * 0.78f, height * 0.93f, unit)
        unit.textSize = width * 0.075f
    }
}

/** Barra horizontal de progreso (RPM). */
class BarView(ctx: Context) : View(ctx) {
    private var frac = 0f
    private var hot = false
    private val back = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#22FFFFFF") }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(f: Float, isHot: Boolean) {
        frac = f.coerceIn(0f, 1f)
        hot = isHot
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(RectF(0f, 0f, w, h), h / 2, h / 2, back)
        if (frac > 0f) {
            fill.shader = if (hot) {
                LinearGradient(0f, 0f, w, 0f, UI.WARN, Color.parseColor("#FF6A4D"), Shader.TileMode.CLAMP)
            } else {
                LinearGradient(0f, 0f, w, 0f, UI.ACCENT, UI.GLOW, Shader.TileMode.CLAMP)
            }
            c.drawRoundRect(RectF(0f, 0f, w * frac, h), h / 2, h / 2, fill)
        }
    }
}

/** Resplandor azul elíptico debajo del auto. */
class PlatformView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.parseColor("#992F8BFF")
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2
        val cy = h / 2
        p.shader = RadialGradient(
            cx, cy, w / 2,
            intArrayOf(Color.parseColor("#8C2F8BFF"), Color.parseColor("#2E2F8BFF"), Color.parseColor("#002F8BFF")),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        c.save()
        c.scale(1f, h / w, cx, cy)
        c.drawCircle(cx, cy, w / 2, p)
        c.restore()
        line.strokeWidth = 2f * d
        c.drawOval(RectF(w * 0.12f, cy - h * 0.28f, w * 0.88f, cy + h * 0.28f), line)
    }
}

/** Controles de musica: anterior, play/pausa, siguiente. */
class TransportView(
    ctx: Context,
    private val onPrev: () -> Unit,
    private val onPlay: () -> Unit,
    private val onNext: () -> Unit
) : View(ctx) {
    var playing = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = UI.TEXT; style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = UI.TEXT; style = Paint.Style.STROKE }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = h * 0.30f
        val cx = w / 2
        val cy = h / 2
        ring.strokeWidth = h * 0.06f
        c.drawCircle(cx, cy, h * 0.46f, ring)
        if (playing) {
            c.drawRect(cx - s * 0.55f, cy - s, cx - s * 0.15f, cy + s, fill)
            c.drawRect(cx + s * 0.15f, cy - s, cx + s * 0.55f, cy + s, fill)
        } else {
            val p = Path()
            p.moveTo(cx - s * 0.5f, cy - s)
            p.lineTo(cx + s * 0.8f, cy)
            p.lineTo(cx - s * 0.5f, cy + s)
            p.close()
            c.drawPath(p, fill)
        }
        val px = w * 0.2f
        c.drawRect(px - s, cy - s * 0.8f, px - s + s * 0.25f, cy + s * 0.8f, fill)
        val p1 = Path()
        p1.moveTo(px + s, cy - s * 0.8f)
        p1.lineTo(px - s * 0.7f, cy)
        p1.lineTo(px + s, cy + s * 0.8f)
        p1.close()
        c.drawPath(p1, fill)
        val nx = w * 0.8f
        c.drawRect(nx + s * 0.75f, cy - s * 0.8f, nx + s, cy + s * 0.8f, fill)
        val p2 = Path()
        p2.moveTo(nx - s, cy - s * 0.8f)
        p2.lineTo(nx + s * 0.7f, cy)
        p2.lineTo(nx - s, cy + s * 0.8f)
        p2.close()
        c.drawPath(p2, fill)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val f = e.x / width
            when {
                f < 0.35f -> onPrev()
                f > 0.65f -> onNext()
                else -> onPlay()
            }
        }
        return true
    }
}

/** Icono de respaldo: cuadro redondeado con la inicial de la app. */
class LetterDrawable(private val letter: String, bgColor: Int) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgColor }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = UI.FONT_B
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val r = b.width() * 0.28f
        c.drawRoundRect(RectF(b), r, r, bg)
        t.textSize = b.height() * 0.5f
        c.drawText(letter, b.exactCenterX(), b.exactCenterY() + t.textSize * 0.35f, t)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}


/** Icono del boton "Aplicaciones": cuadricula de 3x3 puntos sobre fondo azul. */
class AppsIconDrawable : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun draw(c: Canvas) {
        val b = bounds
        bg.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            Color.parseColor("#1F4FD8"), Color.parseColor("#2F8BFF"), Shader.TileMode.CLAMP
        )
        val r = b.width() * 0.28f
        c.drawRoundRect(RectF(b), r, r, bg)
        val step = b.width() * 0.22f
        val cx = b.exactCenterX()
        val cy = b.exactCenterY()
        for (i in -1..1) for (j in -1..1) c.drawCircle(cx + i * step, cy + j * step, b.width() * 0.055f, dot)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Icono del clima dibujado a mano: sol, luna, nubes, lluvia, nieve, niebla y tormenta. */
class WeatherIconView(ctx: Context) : View(ctx) {
    private var code = -1
    private var day = true
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DCE9FF"); style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#DCE9FF"); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val bolt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FFD66B"); style = Paint.Style.FILL }

    fun set(weatherCode: Int, isDay: Boolean) {
        code = weatherCode
        day = isDay
        invalidate()
    }

    private fun cloud(c: Canvas, w: Float, ox: Float, oy: Float, s: Float) {
        c.save()
        c.translate(ox, oy)
        c.scale(s, s)
        c.drawCircle(w * 0.30f, w * 0.56f, w * 0.17f, ink)
        c.drawCircle(w * 0.50f, w * 0.44f, w * 0.23f, ink)
        c.drawCircle(w * 0.72f, w * 0.57f, w * 0.16f, ink)
        c.drawRoundRect(RectF(w * 0.13f, w * 0.52f, w * 0.88f, w * 0.74f), w * 0.11f, w * 0.11f, ink)
        c.restore()
    }

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawCircle(cx, cy, r, ink)
        line.strokeWidth = r * 0.28f
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val x1 = cx + Math.cos(a).toFloat() * r * 1.5f
            val y1 = cy + Math.sin(a).toFloat() * r * 1.5f
            val x2 = cx + Math.cos(a).toFloat() * r * 1.95f
            val y2 = cy + Math.sin(a).toFloat() * r * 1.95f
            c.drawLine(x1, y1, x2, y2, line)
        }
    }

    private fun moon(c: Canvas, cx: Float, cy: Float, r: Float) {
        val a = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        val b = Path().apply { addCircle(cx + r * 0.55f, cy - r * 0.35f, r * 0.85f, Path.Direction.CW) }
        a.op(b, Path.Op.DIFFERENCE)
        c.drawPath(a, ink)
    }

    private fun drops(c: Canvas, w: Float, n: Int, snow: Boolean) {
        line.strokeWidth = w * 0.07f
        for (i in 0 until n) {
            val x = w * (0.30f + i * (0.40f / (n - 1).coerceAtLeast(1)))
            if (snow) c.drawCircle(x, w * 0.88f, w * 0.045f, ink)
            else c.drawLine(x + w * 0.04f, w * 0.80f, x - w * 0.03f, w * 0.95f, line)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        when (code) {
            0, 1 -> if (day) sun(c, w * 0.5f, w * 0.5f, w * 0.20f) else moon(c, w * 0.5f, w * 0.5f, w * 0.30f)
            2 -> {
                if (day) sun(c, w * 0.34f, w * 0.34f, w * 0.12f) else moon(c, w * 0.34f, w * 0.34f, w * 0.18f)
                cloud(c, w, w * 0.12f, w * 0.14f, 0.85f)
            }
            3 -> cloud(c, w, 0f, w * 0.05f, 1f)
            45, 48 -> {
                cloud(c, w, 0f, -w * 0.08f, 0.95f)
                line.strokeWidth = w * 0.06f
                c.drawLine(w * 0.2f, w * 0.78f, w * 0.8f, w * 0.78f, line)
                c.drawLine(w * 0.3f, w * 0.92f, w * 0.7f, w * 0.92f, line)
            }
            71, 73, 75, 77, 85, 86 -> {
                cloud(c, w, 0f, -w * 0.10f, 1f)
                drops(c, w, 3, true)
            }
            95, 96, 99 -> {
                cloud(c, w, 0f, -w * 0.10f, 1f)
                val p = Path()
                p.moveTo(w * 0.52f, w * 0.68f)
                p.lineTo(w * 0.38f, w * 0.88f)
                p.lineTo(w * 0.50f, w * 0.88f)
                p.lineTo(w * 0.44f, w * 1.0f)
                p.lineTo(w * 0.66f, w * 0.80f)
                p.lineTo(w * 0.53f, w * 0.80f)
                p.close()
                c.drawPath(p, bolt)
            }
            -1 -> cloud(c, w, 0f, w * 0.05f, 1f)
            else -> {
                cloud(c, w, 0f, -w * 0.10f, 1f)
                drops(c, w, 3, false)
            }
        }
    }
}

/** Gota de humedad. */
class DropView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = UI.ACCENT; style = Paint.Style.FILL }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val path = Path()
        path.moveTo(w / 2, 0f)
        path.cubicTo(w * 1.05f, h * 0.55f, w * 0.95f, h, w / 2, h)
        path.cubicTo(w * 0.05f, h, -w * 0.05f, h * 0.55f, w / 2, 0f)
        path.close()
        c.drawPath(path, p)
    }
}
